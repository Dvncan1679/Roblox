<!doctype html>
<html lang="en">
  <head>
    <script async src="https://stats.delusionz.xyz/script.js" data-website-id="02885088-5565-472b-bb37-25b2fd56e3f7"></script>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/emerald.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="/uv/uv.bundle.js" defer></script>
    <script src="/uv/uv.config.js" defer></script>
    <title>Emerald</title>
    <script type="module" crossorigin src="/assets/index-0aac1b17.js"></script>
    <link rel="stylesheet" href="/assets/index-04612477.css">
  </head>
  <body>
    <div id="root"></div>
    
    <script
    type="text/javascript"
    src="//pl20795603.highcpmrevenuegate.com/a4/71/c6/a471c618840eda0b00356bec9c8772cf.js"
  ></script>
  <script src=""></script>
  </body>
</html>
